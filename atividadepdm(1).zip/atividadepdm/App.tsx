import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import ListaScreen from './src/screens/stack/List';
import FormScreen from './src/screens/stack/FormList';
import TabNav from './src/screens/tab/Tab';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator 
        initialRouteName="MinhaLista"
        screenOptions={{
          headerStyle: { backgroundColor: '#2196F3' },
          headerTintColor: '#fff',
        }}
      >
        <Tab.Screen 
          name="MinhaLista" 
          component={ListaScreen} 
          options={{ title: 'Minha Lista' }} 
        />
        <Tab.Screen 
          name="Formulario" 
          component={FormScreen} 
          options={{ title: 'Novo Item' }} 
        />
        <Tab.Screen 
          name="OutraTab"
          component={TabNav} 
          options={{ title: 'Navegação Tab' }} 
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}