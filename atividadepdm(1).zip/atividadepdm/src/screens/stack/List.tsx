import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';

export default function ListaScreen({ navigation, route }) {
  const [itens, setItens] = useState([
    { id: '1', nome: 'Exemplo de Item' }
  ]);

  React.useEffect(() => {
    if (route.params?.novoItem) {
      setItens((prev) => [...prev, { id: Math.random().toString(), nome: route.params.novoItem }]);
    }
  }, [route.params?.novoItem]);

  return (
    <View style={styles.container}>
      <FlatList
        data={itens}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text>{item.nome}</Text>
          </View>
        )}
      />
      <TouchableOpacity 
        style={styles.fab} 
        onPress={() => navigation.navigate('Formulario')}
      >
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  item: { padding: 15, backgroundColor: '#ffff', marginBottom: 10, borderRadius: 5 },
  fab: {
    position: 'absolute',
    right: 30,
    bottom: 30,
    backgroundColor: '#2196F3',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5
  },
fabText: { color: 'white', fontSize: 30, fontWeight: 'bold' }
});