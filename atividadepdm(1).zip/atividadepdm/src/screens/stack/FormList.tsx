import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

export default function FormScreen({ navigation }) {
  const [texto, setTexto] = useState('');

  const salvar = () => {
    if (texto.trim()) {
      navigation.navigate('MinhaLista', { novoItem: texto });
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Digite o nome do item"
        value={texto}
        onChangeText={setTexto}
      />
      <Button title="Adicionar na Lista" onPress={salvar} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 2, justifyContent: 'center' },
  input: {
    borderWidth: 1,
    borderColor: '#2196F3',
    padding: 10,
    marginBottom: 20,
    borderRadius: 5,
    color: '#000'
}
});